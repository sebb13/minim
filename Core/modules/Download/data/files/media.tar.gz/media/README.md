# This project is licensed under the terms of the GNU GPL3 license.
# media is a minim's plugin
# documentation : https://minim.webearthquake.com/FR/plugins/mediaPlugin.html
