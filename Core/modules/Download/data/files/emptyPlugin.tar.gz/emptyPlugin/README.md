# This project is licensed under the terms of the GNU GPL3 license.
# find here an empty minim's plugin
# documentation : https://minim.webearthquake.com/FR/documentation/modular.html
